import pandas as pd
import os

# Directory containing your opcode files
directory_path = r'/home/kali/Documents/Cleanopcodes/'  # Replace with your directory path if different
output_path = r'/home/kali/Documents/output.xlsx'

# Initialize list to store data for each file
data = []

# Loop through each file in the directory
for filename in os.listdir(directory_path):
    if filename.endswith('.opcode'):  # Only process opcode files
        file_path = os.path.join(directory_path, filename)
        
        # Read the opcodes from the file and join with commas
        with open(file_path, 'r') as file:
            opcodes = ', '.join(line.strip() for line in file.readlines())
        
        # Extract the APT group name (part before the first underscore)
        apt_group = filename.split('_')[0]
        
        # Append APT group and opcodes to the data list
        data.append({'Opcodes': opcodes, 'APT Group': apt_group})

# Create a DataFrame from the list of dictionaries
df = pd.DataFrame(data)

# Identify rows with non-string entries in the 'Opcodes' column
non_string_data = df[df['Opcodes'].apply(lambda x: not isinstance(x, str))]

# Export the DataFrame and non-string data to an Excel file with separate sheets
with pd.ExcelWriter(output_path) as writer:
    df.to_excel(writer, sheet_name='Opcode Data', index=False)
    non_string_data.to_excel(writer, sheet_name='Non-string Entries', index=False)

print(f"Data exported successfully to {output_path}")
