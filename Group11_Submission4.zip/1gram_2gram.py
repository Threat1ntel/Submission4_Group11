import pandas as pd
from collections import Counter

# Function to perform n-gram analysis
def ngram_analysis(opcode_sequences, n=1):
    ngram_counts = Counter()
    
    for sequence in opcode_sequences:
        opcodes = sequence.split(", ")
        
        if n == 1:  # 1-gram analysis (individual opcodes)
            ngram_counts.update(opcodes)
        elif n == 2:  # 2-gram analysis (consecutive opcode pairs)
            ngram_counts.update(zip(opcodes, opcodes[1:]))
    
    return ngram_counts

# Load the Excel file and clean any non-string values
output_path = r"C:\nishit\UNi_MCTI\Threat intel\Ass1\Project\Submission4\output.xlsx"
output_data = pd.read_excel(output_path)
opcode_sequences = output_data['Opcodes'].fillna("").astype(str).tolist()

# Perform 1-gram and 2-gram analysis
one_gram_counts = ngram_analysis(opcode_sequences, n=1)
two_gram_counts = ngram_analysis(opcode_sequences, n=2)

# Convert the results to DataFrames
one_gram_df = pd.DataFrame(one_gram_counts.items(), columns=['Opcode', 'Frequency']).sort_values(by='Frequency', ascending=False)
two_gram_df = pd.DataFrame(two_gram_counts.items(), columns=['Opcode Pair', 'Frequency']).sort_values(by='Frequency', ascending=False)

# Save the results to an Excel file with separate sheets for each analysis
output_ngrams_path = r"C:\nishit\UNi_MCTI\Threat intel\Ass1\Project\Submission4\ngram_analysis.xlsx"
with pd.ExcelWriter(output_ngrams_path) as writer:
    one_gram_df.to_excel(writer, sheet_name='1-gram Analysis', index=False)
    two_gram_df.to_excel(writer, sheet_name='2-gram Analysis', index=False)

